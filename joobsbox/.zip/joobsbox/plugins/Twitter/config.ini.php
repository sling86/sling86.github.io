[main]
image				  =	images/twitter24.png
title_ro			=	Twitter
title_en			=	Twitter
version       = 0.1
author        = Valentin Bora
description   = "Twitter plugin enables your Joobsbox to post new jobs on Twitter. Made by <a href="http://valentinbora.com">Valentin Bora</a>"

[main]
title_en  = Hello
version   = 1.0
image     = hello.png
description = Hello plugin has a crucial importance to Joobsbox. Nothing more to say.

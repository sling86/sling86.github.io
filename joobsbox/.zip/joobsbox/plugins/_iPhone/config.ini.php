[main]
title_ro			=	iPhone
title_en			=	iPhone
image				  =	images/iphone_24.png
version       = 0.1
author        = Manuel Ciosici <manuelrciosici@gmail.com>
description   = "This is the iPhone compatibility and optimization plugin made by <a href="http://manuelciosici.com">Manuel R. Ciosici</a>"

[main]
title_ro			=	Anunțuri
title_en			=	Postings
image				=	images/postings_24.png

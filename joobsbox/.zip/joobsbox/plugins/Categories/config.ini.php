[main]
title_ro			=	Categorii
title_en			=	Categories
image				=	images/categories_24.png

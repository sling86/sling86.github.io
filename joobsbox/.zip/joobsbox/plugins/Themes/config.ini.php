[main]
title_ro			=	Stiluri
title_en			=	Themes
image				  =	images/themes_24.png

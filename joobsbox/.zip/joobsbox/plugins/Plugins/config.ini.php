[main]
title_ro			=	Module
title_en			=	Plugins
image				  =	images/plugins_24.png

#!/bin/bash
chmod ugo+w config/
chmod ugo+w config/config.ini.php
chmod ugo+w Joobsbox/SearchIndexes
chmod ugo+w cache/

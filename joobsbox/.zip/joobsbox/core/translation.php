<?php
// This file contains extra strings that have to be translated but are contained in external libraries such as Zend Framework
translate("Value is required and can't be empty");

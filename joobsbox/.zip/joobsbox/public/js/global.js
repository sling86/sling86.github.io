$(document).ready(function() {
	$('div.inner').wrap('<div class="outer"></div>');

	$("#searchInput").click(function(ev) {
		$(ev.target).attr("value", "");
	});
});

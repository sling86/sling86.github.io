<?php
/**
 * Contains strings that need translation and are not available anywhere else
 * 
 * Manages job display
 *
 * @author Valentin Bora <contact@valentinbora.com>
 * @version 1.0
 * @package Joobsbox_Controllers
 */
 
/**
 * @package Joobsbox_Controllers
 */

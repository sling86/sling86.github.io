[general]
dev = "1"
jobs_per_categ = "10"
standalone = "1"
admin_theme = "joobsbox grey"
theme = "default"
common_title = "Joobs"
locale = "en"
timezone = "Europe/Berlin"
posting_ttl = "30"

[rss]
all_jobs_count = "15"
category_jobs_count = "15"
description = ""

[db]
prefix = ""

[dbtables]
postings = "jobs"
categories = "categories"
users = "users"

